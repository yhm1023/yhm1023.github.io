<?php
if(!defined('IN_CRONLITE'))exit();
if(checkmobile() && !$_GET['pc'] || $_GET['mobile']){include_once TEMPLATE_ROOT.'faka/wapbuy.php';exit;}

function escape($string, $in_encoding = 'UTF-8',$out_encoding = 'UCS-2') { 
    $return = ''; 
    if (function_exists('mb_get_info')) { 
        for($x = 0; $x < mb_strlen ( $string, $in_encoding ); $x ++) { 
            $str = mb_substr ( $string, $x, 1, $in_encoding ); 
            if (strlen ( $str ) > 1) { // 多字节字符 
                $return .= '%u' . strtoupper ( bin2hex ( mb_convert_encoding ( $str, $out_encoding, $in_encoding ) ) ); 
            } else { 
                $return .= '%' . strtoupper ( bin2hex ( $str ) ); 
            } 
        } 
    } 
    return $return; 
}

if($islogin2==1){
	$price_obj = new \lib\Price($userrow['zid'],$userrow);
}elseif($is_fenzhan == true){
	$price_obj = new \lib\Price($siterow['zid'],$siterow);
}else{
	$price_obj = new \lib\Price(1);
}

$tid=intval($_GET['tid']);
$tool=$DB->getRow("select * from pre_tools where tid='$tid' limit 1");
if(!$tool || $tool['active']!=1)sysmsg('当前商品不存在');
if($tool['close']==1)sysmsg('当前商品维护中，停止下单！');

if(isset($price_obj)){
	$price_obj->setToolInfo($tool['tid'],$tool);
	if($price_obj->getToolDel($tool['tid'])==1)sysmsg('商品已下架');
	$price=$price_obj->getToolPrice($tool['tid']);
}else $price=$tool['price'];


if($tool['is_curl']==4){
	$count = $DB->getColumn("SELECT count(*) FROM pre_faka WHERE tid='{$tool['tid']}' and orderid=0");
	$fakainput = getFakaInput();
	if($fakainput!='hide')$tool['input']=$fakainput;
	else $tool['input']=null;
	$isfaka = 1;
}else{
	$isfaka = 0;
}
if($tool['is_curl']==1||$tool['is_curl']==2||$tool['is_curl']==4){
	$isauto = true;
}else{
	$isauto = false;
}

include_once TEMPLATE_ROOT.'faka/head.php';

?>
<link rel="stylesheet" href="assets/faka/css/buy.css" />
<br/>
<div class="topliucheng"><img src="<?php echo $cdnserver?>assets/faka/images/goumaizn02.png" title=""></div>

<div id="body">

<div class="bobo">

<div class="left">

<div class="top">

<div class="tou"><img src="<?php echo $tool['shopimg']?$tool['shopimg']:'assets/faka/images/default.jpg';?>" width="150" alt="<?php echo $tool['name']?>" /></div>

<div class="bianhao">商品编号：NO.<?php echo $tid?><br />

<font color="#ff0000"  size="2">
售价：<?php echo $price?> 元</font>
</div>

<div class="wu"></div><div class="bianhao">
手机扫码购买<br/>
<img src="https://www.liantu.com/api.php?w=150&m=10&text=<?php echo $siteurl?>">
</div>
</div>

</div>
<div class="rigth">
<div class="trade-goodinfo">
<?php echo $tool['name']?></div>
<div class="trade-goodinfo2">
		<span  style="color:#080808">售价</span>
		<span class="trade-price">¥<?php echo $price?></span>
														

		<span style="float:right"><?php echo $isauto?'<img src="assets/faka/images/zdfh.png">':'<img src="assets/faka/images/sdfh.png">';?>

		</span>
</div><br/>

<input type="hidden" id="tid" value="<?php echo $tid?>" cid="<?php echo $tool['cid']?>" price="<?php echo $tool['price']?>" alert="<?php echo escape($tool['alert'])?>" inputname="<?php echo $tool['input']?>" inputsname="<?php echo $tool['inputs']?>" multi="<?php echo $tool['multi']?>" isfaka="<?php echo $isfaka?>" count="<?php echo $tool['value']?>" close="<?php echo $tool['close']?>" prices="<?php echo $tool['prices']?>" max="<?php echo $tool['max']?>" min="<?php echo $tool['min']?>">
<input type="hidden" id="leftcount" value="<?php echo $tool['is_curl']==2?100:$count?>">

<div id="inputsname"></div>
<?php if($tool['multi']==1){?>
<div class="from">
 <div class="from_wz_3">购买数量：</div>
 <div class="from_in_2">
 <input id="num" name="num" class="z" type="number" value="1" placeholder="请输入购买数量" required min="1" max="<?php echo $count?>" >
 </div>
 <?php if($isfaka){?>
 <div class="from_in_2 yanzheng" style="width:200px"> <font size="2" color="#FF7200"> 库存<?php echo $tool['is_curl']==2?'充足':$count.'个'?></span> </div>
 <?php }?>
 </div>
<?php }?>


      <div class="from">

        <div class="from_off_4"></div>
		<div class="from_in_4" style="width:100px">
		
		<input type="button" style="cursor:pointer;" class="button button-3d button-primary button-small" value="立即购买" id="submit_buy"/>
		
	
		</div> <div class="from_in_2 yanzheng" style="width:100px">
	 <a href="#" onclick="javascript:history.go(-1);" class="button button-3d button-highlight button-rounded button-small">返回</a></div>
        </div>


		
 <div class="trade-goodinfo2">
	  商品介绍：
      </div>
      <div class="xiangqing">
	  <p>
	  <?php echo $tool['desc']?></p>      </div>

</div>

</div>

</div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnpublic?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script type="text/javascript">
var hashsalt=<?php echo $addsalt_js?>;
</script>
<script src="assets/js/faka.js?ver=<?php echo VERSION ?>"></script>
<div id="footer">
    		&copy; 2020 <?php echo $conf['sitename']?>
</div>
