<?php
if(!defined('IN_CRONLITE'))exit();

include_once TEMPLATE_ROOT.'faka/head.php';
?>
<div id="bd">

<div id="bar">
<div class="bar_top">关于我们</div><br />

<ul id="bar_ul">
<li class="va"><a href="./?mod=about">关于我们</a></li>
<li ><a href="./?mod=help">帮助中心</a></li>
</ul>
</div>


<div id="bar_r">


<div id="body_xiao">


    	<div class="table">








<br/>
<span class="title"><p style="text-align: center;">
    <strong style="font-size: 30px; white-space: normal;">关于<?php echo $conf['sitename']?></strong>
</p></span><br/>

    	
<span ><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp; &nbsp; &nbsp; &nbsp;<?php echo $conf['sitename']?>是优云网计算机科技有限公司旗下网站之一,致力于打造中国最受欢迎的网络游戏及数字产品自动发卡程序的综合解决方案服务商。专业为不同领域不同客户提供专业化的“私人定制”服务。为用户提供价廉物美的虚拟商品和完美的用户体验。同时提供手游交易，多种交易软件、自动化交易处理等行业独创的特色服务。</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">我们打破了传统虚拟交易网站几年来一成不变的局面，建立了新一代虚拟游戏交易网站的行业方向，我们将引领的网络游戏交易产品的个性化、自动化、工具化等。作为业内最善于创新的网站，力争成为行业的佼佼者。</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">我们承诺将秉承“客户至上”的经营理念，关注好每一个细节，不断完善用户体验，优化安全机制，努力提升服务质量。</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">我们相信，在每位职员的努力下，开创性的虚拟交易时代即将来临。</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft=""><span style="color: rgb(255, 102, 0);"><strong><span style="font-size: medium;">团队力量</span></strong></span></p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 年轻活力、朝气蓬勃</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft=""><span style="font-size: small;">&nbsp;&nbsp;&nbsp; 积极向上、团结互助</span></p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 善于思考、擦亮眼睛做对事</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft=""><span style="color: rgb(255, 102, 0); font-size: medium;"><strong>经营理念</strong></span></p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 不断创新，共同成长</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 客户至上，用最真挚的态度为客户服务</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 始终如一，为梦想而努力奋斗！</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft=""><strong><span style="color: rgb(255, 102, 0); font-size: medium;">核心价值</span></strong></p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;</p><p style="padding: 0px; color: rgb(51, 51, 51); font-family:;" microsoft="">&nbsp;&nbsp;&nbsp; 客户第一、以人为本、团队利益、诚信负责</p></span>
        	


</div>
</div>
</div>
</div></div>
<div id="footer">
    		&copy; 2020 <?php echo $conf['sitename']?>
</div>
