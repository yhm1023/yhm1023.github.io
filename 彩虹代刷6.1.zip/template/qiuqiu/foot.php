
    <footer id="footer">

        <div class="copyright">
		<?php echo $conf['bottom']?>
			</script>
        </div>

    </footer>
	</div>
	</div>
	</div>
    <div id="loading"></div> 
	
</body>
	
</html>