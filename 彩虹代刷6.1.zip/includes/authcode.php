<?php
$authcode='阡叶破解,勿删版权,交流群：682234967';
$distid='0';
?>