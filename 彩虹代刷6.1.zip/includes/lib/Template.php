<?php
namespace lib;

class Template {

	static public function getList(){
		$dir = TEMPLATE_ROOT;
		$dirArray[] = NULL;
        if (false != ($handle = opendir($dir))) {
            $i = 0;
            while (false !== ($file = readdir($handle))) {
                if ($file != "." && $file != ".." && !strpos($file, ".")) {
                    $dirArray[$i] = $file;
                    $i++;
                }
            }
            closedir($handle);
        }
        return $dirArray;
	}

	static public function load($name = 'index'){
		global $conf;
		$template = $conf['template']?$conf['template']:'default';
		if(!preg_match('/^[a-zA-Z0-9]+$/',$name))exit('error');
		$filename = TEMPLATE_ROOT.$template.'/'.$name.'.php';
		$filename_default = TEMPLATE_ROOT.'default/'.$name.'.php';
		if(file_exists($filename)){
			return $filename;
		}elseif(file_exists($filename_default)){
			return $filename_default;
		}else{
			exit('Template file not found');
		}
	}

	static public function exists($template){
		$filename = TEMPLATE_ROOT.$template.'/index.php';
		if(file_exists($filename)){
			return true;
		}else{
			return false;
		}
	}

	static public function getBackground($path=null){
		global $conf,$DB,$CACHE;
		if($conf['ui_bing']==1){
			$background_image='//cdn.qqzzz.net/assets/img/background/'.rand(1,19).'.jpg';
			$background_css = '<style>body{ background:#ecedf0 url("'.$background_image.'") fixed;background-repeat:no-repeat;background-size:100% 100%;}</style>';
		}elseif($conf['ui_bing']==2){
			if(date("Ymd")==$conf['ui_bing_date']){
				$background_image=$conf['ui_backgroundurl'];
				if(checkmobile()==true)$background_image=str_replace('1920x1080','768x1366',$background_image);
			}else{
				$url = 'https://cn.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=zh-CN';
				$bing_data = get_curl($url);
				$bing_arr=json_decode($bing_data,true);
				if (!empty($bing_arr['images'][0]['url'])) {
					$background_image='//cn.bing.com'.$bing_arr['images'][0]['url'];
					saveSetting('ui_backgroundurl', $background_image);
					saveSetting('ui_bing_date', date("Ymd"));
					$CACHE->clear();
					if(checkmobile()==true)$background_image=str_replace('1920x1080','768x1366',$background_image);
				}
			}
			$background_css = '<style>body{ background:#ecedf0 url("'.$background_image.'") fixed;background-repeat:no-repeat;background-size:100% 100%;}</style>';
		}elseif($conf['ui_bing']==3){
			if($conf['ui_colorto']==1){
				$background_css = '<style>body{ background: linear-gradient(to right,'.$conf['ui_color1'].','.$conf['ui_color2'].') fixed;}</style>';
			}else{
				$background_css = '<style>body{ background: linear-gradient(to bottom,'.$conf['ui_color1'].','.$conf['ui_color2'].') fixed;}</style>';
			}
		}else{
			$background_image=$path.'assets/img/bj.png';
			if($conf['ui_background']==0)
			$repeat='background-repeat:repeat;';
			elseif($conf['ui_background']==1)
			$repeat='background-repeat:repeat-x; background-size:auto 100%;';
			elseif($conf['ui_background']==2)
			$repeat='background-repeat:repeat-y; background-size:100% auto;';
			elseif($conf['ui_background']==3)
			$repeat='background-repeat:no-repeat; background-size:100% 100%;';
			$background_css = '<style>body{ background:#ecedf0 url("'.$background_image.'") fixed;'.$repeat.'}</style>';
		}
		return [$background_image, $background_css];
	}
}
